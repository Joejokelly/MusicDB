package com.rest.webservices.restfulwebservics.album;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rest.webservices.restfulwebservics.artist.Artist;

@Repository
public interface AlbumRepository extends JpaRepository<Album, Integer>  {

}


package com.rest.webservices.restfulwebservics.artist;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;

import com.rest.webservices.restfulwebservics.album.Album;
import com.rest.webservices.restfulwebservics.model.BaseModel;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Artist  {
	@Id
	@GeneratedValue
	private Integer Id;
	private String name;

	@OneToMany(mappedBy="artist")
	private List<Album> albums;
	

	public Artist() {
		
	}
	
	public Artist(String name) {
		super();
		this.name = name;
	}
	
	public Artist(Integer id, String name) {
		//super(id, new Date(), new Date());
		this.Id = id;
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public List<Album> getAlbums() {
		return albums;
	}

	public void setAlbums(List<Album> albums) {
		this.albums = albums;
	}

	
	@Override
	public String toString() {
		return "Artist [name=" + name + "]";
	}
	

}

package com.rest.webservices.restfulwebservics.album;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.rest.webservices.restfulwebservics.artist.Artist;
import com.rest.webservices.restfulwebservics.model.BaseModel;
import com.rest.webservices.restfulwebservics.song.Song;

@Entity
public class Album  {
	
	@Id
	@GeneratedValue
	private Integer id;
	
	private String name;
	private int yearReleased;
	
	@OneToMany(mappedBy="album")
	private List<Song> songs;
	
	

	@ManyToOne(fetch=FetchType.LAZY)
	@JsonIgnore
	private Artist artist;
	

	public Album() {
		
	}
	
	public Album(int id, String name, int yearReleased) {
		super();
		this.name = name;
		this.yearReleased = yearReleased;
	}
	
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Artist getArtist() {
		return artist;
	}

	public void setArtist(Artist artist) {
		this.artist = artist;
	}

	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getYearReleased() {
		return yearReleased;
	}
	public void setYearReleased(int yearReleased) {
		this.yearReleased = yearReleased;
	}

	public List<Song> getSongs() {
		return songs;
	}

	public void setSongs(List<Song> songs) {
		this.songs = songs;
	}

	
	@Override
	public String toString() {
		return "Album [name=" + name + ", yearReleased=" + yearReleased + "]";
	}
	

	
}

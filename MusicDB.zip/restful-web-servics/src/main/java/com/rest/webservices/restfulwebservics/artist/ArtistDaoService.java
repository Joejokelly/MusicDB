package com.rest.webservices.restfulwebservics.artist;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class ArtistDaoService {
	private static List<Artist> artists = new ArrayList<>();
	private static int artistsCount = 3;
	
	static {
		artists.add(new Artist(1, "Adam"));
		artists.add(new Artist(2, "Eve"));
		artists.add(new Artist(3, "Jack"));
		
		//artists.add(new Artist(2, new Date(), new Date(), "Eve"));
		//artists.add(new Artist(3, new Date(), new Date(), "Jack"));
		
	}

	public List<Artist> findAll() {
		return artists;
	}
	
	public Artist save(Artist artist) {
		if (artist.getId() == null) {
			artist.setId(++artistsCount);
		}
		artists.add(artist);
		return artist;
	}
	
	
	public Artist findOne(int id) {
		for (Artist artist : artists) {
			if (artist.getId() == id) {
				return artist;
			}
		}
		return null;
	}
	
	public Artist deleteById(int id) {
		Iterator<Artist> iterator = artists.iterator();
		
		while (iterator.hasNext()) {
			Artist artist = iterator.next();
			if (artist.getId() == id) {
				iterator.remove();
				return artist;
			}
		}
		
		return null;
	}

	
	
}

package com.rest.webservices.restfulwebservics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfulWebServicsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfulWebServicsApplication.class, args);
	}

}

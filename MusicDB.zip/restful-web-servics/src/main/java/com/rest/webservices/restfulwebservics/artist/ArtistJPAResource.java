package com.rest.webservices.restfulwebservics.artist;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.rest.webservices.restfulwebservics.album.Album;
import com.rest.webservices.restfulwebservics.album.AlbumRepository;
import com.rest.webservices.restfulwebservics.song.Song;
import com.rest.webservices.restfulwebservics.song.SongRepository;

@RestController
public class ArtistJPAResource {

	@Autowired
	private ArtistDaoService service;
	
	@Autowired
	private ArtistRepository artistRepository;
	
	@Autowired
	private AlbumRepository albumRepository;
	
	@Autowired
	private SongRepository songRepository;
	
	
	
	//GET /artists
	//retreiveAllArtists
	
	@GetMapping("/jpa/artists")
	public List<Artist> retreiveAllArtists() {
		return artistRepository.findAll();
	}
	
	//GET /users/{id}
	//retreiveArtist(Long id)

	@GetMapping("/jpa/artists/{id}")
	public Optional<Artist> retreiveArtist(@PathVariable Integer id) {
		Optional<Artist> artist = artistRepository.findById(id);
		
		if (!artist.isPresent()) {
			throw new ArtistNotFoundException("id-" + id);
		}
		
		return artist;
	}

	@DeleteMapping("/jpa/artists/{id}")
	public void deleteArtist(@PathVariable Integer id) {
		artistRepository.deleteById(id);
		
	}

	
	//CREATED
	//input - details of artits
	//output - CREATED & RETURN the created  URI
	
	@PostMapping("/jpa/artists")
	public ResponseEntity<Object> createArtist(@RequestBody Artist artist) {
		Artist savedArtist = artistRepository.save(artist);
		
		URI location = ServletUriComponentsBuilder.
		  fromCurrentRequest()
		  .path("/{id}").
		  buildAndExpand(savedArtist.getId()).toUri();
		
		return ResponseEntity.created(location).build();
		
	}

	@GetMapping("/jpa/artists/{id}/album")
	public List<Album> retreiveAllArtists(@PathVariable int id) {
		
		Optional<Artist> artistOptional = artistRepository.findById(id);
		
		if (!artistOptional.isPresent()) {
			throw new ArtistNotFoundException("id-" + id);				
		}
		return artistOptional.get().getAlbums();
	}

	@PostMapping("/jpa/artists/{id}/album")
	public ResponseEntity<Object> createAlbum(@PathVariable int id, @RequestBody Album album) {
		
		Optional<Artist> artistOptional = artistRepository.findById(id);
		
		if (!artistOptional.isPresent()) {
			throw new ArtistNotFoundException("id-" + id);
		}
		
			Artist artist = artistOptional.get();
			
			album.setArtist(artist);
			
			albumRepository.save(album);
			
			URI location = ServletUriComponentsBuilder.
			  fromCurrentRequest()
			  .path("/{id}").
			  buildAndExpand(album.getId()).toUri();
			
			return ResponseEntity.created(location).build();
			
		}
	
		@GetMapping("/jpa/artists/{id}/album/{album_id}/song")
		public List<Song> retreiveAllSong(@PathVariable int id, @PathVariable int album_id) {
			Optional<Artist> artistOptional = artistRepository.findById(id);
			
			if (!artistOptional.isPresent()) {
				throw new ArtistNotFoundException("id-" + id);
			}

			Optional<Album>  albumOptional = albumRepository.findById(album_id);
			
			Album album = albumOptional.get();
					
			//System.out.println("album xxx " + album.getArtist().getId());
			
			if (id != album.getArtist().getId()) {
				throw new ArtistNotFoundException("id-" + id);
				}
			
			if (!albumOptional.isPresent()) {
				throw new ArtistNotFoundException("album_id" + id);				
			}
			return albumOptional.get().getSongs();
		}

		@PostMapping("/jpa/artists/{id}/album/{album_id}/song")
		
		public ResponseEntity<Object> createSong(@PathVariable int id, @PathVariable int album_id, @RequestBody Song song) {
			Optional<Artist> artistOptional = artistRepository.findById(id);
			
			if (!artistOptional.isPresent()) {
				throw new ArtistNotFoundException("id-" + id);
			}

			Optional<Album>  albumOptional = albumRepository.findById(album_id);
			Album album = albumOptional.get();
			
			//System.out.println("albumxx :" + album);
			//System.out.println("albumidyy :" + album.getArtist().getId());
			//System.out.println("zzzz");
			
			if (!albumOptional.isPresent()) {
				throw new ArtistNotFoundException("album_id" + id);				
			}

			if (id != album.getArtist().getId()) {
				throw new ArtistNotFoundException("id-" + id);
				}

			song.setAlbum(album);		
			songRepository.save(song);
			
			URI location = ServletUriComponentsBuilder.
					  fromCurrentRequest()
					  .path("/{id}").
					  buildAndExpand(album.getId()).toUri();
					
			return ResponseEntity.created(location).build();
						
		}
	
}

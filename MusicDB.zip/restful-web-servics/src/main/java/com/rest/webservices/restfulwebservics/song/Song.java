package com.rest.webservices.restfulwebservics.song;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.rest.webservices.restfulwebservics.album.Album;
import com.rest.webservices.restfulwebservics.artist.Artist;

@Entity
public class Song {
	
	@Id
	@GeneratedValue
	private Integer id;
	
	private Integer track;
	private String name;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JsonIgnore
	private Album album;
	
	
	public Song() {
		
	}
	
	public Song(Integer id, Integer track, String name, Album album) {
		super();
		this.id = id;
		this.track = track;
		this.name = name;
		this.album = album;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getTrack() {
		return track;
	}
	public void setTrack(Integer track) {
		this.track = track;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Album getAlbum() {
		return album;
	}
	public void setAlbum(Album album) {
		this.album = album;
	}
	
	@Override
	public String toString() {
		return "Song [id=" + id + ", track=" + track + ", name=" + name + "]";
	}
	
	
}

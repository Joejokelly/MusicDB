package com.rest.webservices.restfulwebservics.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class BaseModel {
	@Id
	@GeneratedValue
	
	private Integer id;
	private Date created;
	private Date lastModified;
	
	
	public BaseModel() {
		
	}
	
	public BaseModel(Integer id, Date created, Date lastModified) {
		super();
		this.id = id;
		this.created = created;
		this.lastModified = lastModified;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public Date getLastModified() {
		return lastModified;
	}
	public void setLastModified(Date lastModified) {
		this.lastModified = lastModified;
	}
	
	
	@Override
	public String toString() {
		return "BaseModel [id=" + id + ", created=" + created + ", lastModified=" + lastModified + "]";
	}
	
	
}

package com.rest.webservices.restfulwebservics.song;

import org.springframework.data.jpa.repository.JpaRepository;


public interface SongRepository extends JpaRepository<Song, Integer> {

}
